# AliExpress CL-260

Example configuration for the [AliExpress CL-260](https://www.aliexpress.com/item/32812528331.html) Ultimaker 2 clone.

*Note: Change `Z_MAX_POS` to 300 for the CL-260MAX.*

The setting "works" for my printer and the extruder using my calibration value, but you might want to tweak some settings, e.g enable EEPROM, increase default Z speed, adjust homing speeds,...

Have fun!

\- tobi

# Configuration Notes

This configuration is for the Creality CR-10S with a BigTreeTech SKR 2.0 board, TMC2209 stepper drivers, CR-Touch probe, and the Microswiss All-Metal Hotend.

Edit and tune this configuration if you have the stock hotend, no probe, a different probe, etc.
